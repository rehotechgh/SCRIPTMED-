﻿namespace ALENGINE.wwwroot.css2
{
    public class boostraptable
    {
    }
}
